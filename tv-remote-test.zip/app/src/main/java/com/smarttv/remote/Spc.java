package com.smarttv.remote;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Samsung H/J-series "SPC" pairing crypto, ported from SmartCrypto (crypto.py + command_encryption.py). */
public class Spc {
    static final String PUBLIC_KEY = "2cb12bb2cbf7cec713c0fff7b59ae68a96784ae517f41d259a45d20556177c0ffe951ca60ec03a990c9412619d1bee30adc7773088c5721664cffcedacf6d251cb4b76e2fd7aef09b3ae9f9496ac8d94ed2b262eee37291c8b237e880cc7c021fb1be0881f3d0bffa4234d3b8e6a61530c00473ce169c025f47fcc001d9b8051";
    static final String PRIVATE_KEY = "2fd6334713816fae018cdee4656c5033a8d6b00e8eaea07b3624999242e96247112dcd019c4191f4643c3ce1605002b2e506e7f1d1ef8d9b8044e46d37c0d5263216a87cd783aa185490436c4a0cb2c524e15bc1bfeae703bcbc4b74a0540202e8d79cadaae85c6f9c218bc1107d1f5b4b9bd87160e782f4e436eeb17485ab4d";
    static final String WB_KEY = "abbb120c09e7114243d1fa0102163b27";
    static final String TRANS_KEY = "6c9474469ddf7578f3e5ad8a4c703d99";
    static final String PRIME = "b361eb0ab01c3439f2c16ffda7b05e3e320701ebee3e249123c3586765fd5bf6c1dfa88bb6bb5da3fde74737cd88b6a26c5ca31d81d18e3515533d08df619317063224cf0943a2f29a5fe60c1c31ddf28334ed76a6478a1122fb24c4a94c8711617ddfe90cf02e643cd82d4748d6d4a7ca2f47d88563aa2baf6482e124acd7dd";

    static final int SHA_LEN = 20;
    static final int GX_SIZE = 128;

    public static class Hello {
        public byte[] serverHello, hash, aesKey;
    }

    public static class Parsed {
        public byte[] ctx, skPrime;
    }

    // ---------- helpers ----------
    static byte[] sha1(byte[]... parts) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        for (byte[] p : parts) md.update(p);
        return md.digest();
    }

    static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    static byte[] int32(int v) {
        return new byte[]{(byte) (v >>> 24), (byte) (v >>> 16), (byte) (v >>> 8), (byte) v};
    }

    static int readInt32(byte[] d, int pos) {
        return ((d[pos] & 0xff) << 24) | ((d[pos + 1] & 0xff) << 16) | ((d[pos + 2] & 0xff) << 8) | (d[pos + 3] & 0xff);
    }

    public static byte[] unhex(String s) {
        int n = s.length() / 2;
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) out[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return out;
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }

    static byte[] aesCbcZero(byte[] key, byte[] in, boolean enc) throws Exception {
        Cipher c = Cipher.getInstance("AES/CBC/NoPadding");
        c.init(enc ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(new byte[16]));
        return c.doFinal(in);
    }

    static byte[] aesEcb(byte[] key, byte[] in, boolean enc, boolean pad) throws Exception {
        Cipher c = Cipher.getInstance(pad ? "AES/ECB/PKCS5Padding" : "AES/ECB/NoPadding");
        c.init(enc ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"));
        return c.doFinal(in);
    }

    // per-16-byte-block AES with fresh zero IV == ECB, over the first 128 bytes
    static byte[] wb(byte[] in, boolean enc) throws Exception {
        return aesEcb(unhex(WB_KEY), Arrays.copyOf(in, GX_SIZE), enc, false);
    }

    // ---------- pairing ----------
    public static Hello generateServerHello(String userId, String pin) throws Exception {
        byte[] pinHash = sha1(pin.getBytes(StandardCharsets.UTF_8));
        byte[] aesKey = Arrays.copyOf(pinHash, 16);
        byte[] encrypted = aesCbcZero(aesKey, unhex(PUBLIC_KEY), true);
        byte[] swapped = wb(encrypted, true);
        byte[] uid = userId.getBytes(StandardCharsets.UTF_8);
        byte[] data = concat(int32(uid.length), uid, swapped);
        byte[] dataHash = sha1(data);
        byte[] serverHello = concat(new byte[]{1, 2}, new byte[5], int32(uid.length + 132), data, new byte[5]);
        Hello h = new Hello();
        h.serverHello = serverHello;
        h.hash = dataHash;
        h.aesKey = aesKey;
        return h;
    }

    /** returns null if the PIN is wrong / reply malformed */
    public static Parsed parseClientHello(String clientHelloHex, byte[] dataHash, byte[] aesKey, String gUserId) throws Exception {
        final int USER_ID_POS = 15, USER_ID_LEN_POS = 11;
        byte[] data = unhex(clientHelloHex);
        if (data.length < USER_ID_POS) return null;
        int userIdLen = readInt32(data, USER_ID_LEN_POS);
        if (userIdLen < 0 || userIdLen > 64) return null;
        int flagPos = userIdLen + USER_ID_POS + GX_SIZE + SHA_LEN;
        if (data.length < flagPos + 5) return null;
        byte[] userId = Arrays.copyOfRange(data, USER_ID_POS, USER_ID_POS + userIdLen);
        byte[] pEncWBGx = Arrays.copyOfRange(data, USER_ID_POS + userIdLen, USER_ID_POS + userIdLen + GX_SIZE);
        byte[] pEncGx = wb(pEncWBGx, false);
        byte[] pGx = aesCbcZero(aesKey, pEncGx, false);
        BigInteger bnPGx = new BigInteger(1, pGx);
        BigInteger secretNum = bnPGx.modPow(new BigInteger(PRIVATE_KEY, 16), new BigInteger(PRIME, 16));
        byte[] dataHash2 = Arrays.copyOfRange(data, USER_ID_POS + userIdLen + GX_SIZE, USER_ID_POS + userIdLen + GX_SIZE + SHA_LEN);

        // minimal big-endian bytes (what the original python does), fallback: fixed 128 bytes
        byte[] minimal = secretNum.toByteArray();
        if (minimal.length > 1 && minimal[0] == 0) minimal = Arrays.copyOfRange(minimal, 1, minimal.length);
        byte[] fixed = new byte[GX_SIZE];
        byte[] full = secretNum.toByteArray();
        int start = Math.max(0, full.length - GX_SIZE);
        System.arraycopy(full, start, fixed, GX_SIZE - (full.length - start), full.length - start);

        byte[] secret = null;
        for (byte[] cand : new byte[][]{minimal, fixed}) {
            if (Arrays.equals(sha1(userId, cand), dataHash2)) { secret = cand; break; }
        }
        if (secret == null) return null; // pin error

        if (data[flagPos] != 0) return null;
        if (readInt32(data, flagPos + 1) != 0) return null;

        byte[] finalBuffer = concat(userId, gUserId.getBytes(StandardCharsets.UTF_8), pGx, unhex(PUBLIC_KEY), secret);
        byte[] skPrime = sha1(finalBuffer);
        byte[] skPrimeHash = sha1(skPrime, new byte[]{0});
        byte[] ctx = aesEcb(unhex(TRANS_KEY), Arrays.copyOf(skPrimeHash, 16), true, false);
        Parsed p = new Parsed();
        p.ctx = ctx;
        p.skPrime = skPrime;
        return p;
    }

    public static String generateServerAcknowledge(byte[] skPrime) throws Exception {
        byte[] h = sha1(skPrime, new byte[]{1});
        return "0103000000000000000014" + hex(h).toUpperCase() + "0000000000";
    }

    public static boolean parseClientAcknowledge(String clientAck, byte[] skPrime) throws Exception {
        byte[] h = sha1(skPrime, new byte[]{2});
        String expected = "0104000000000000000014" + hex(h).toUpperCase() + "0000000000";
        return expected.equalsIgnoreCase(clientAck);
    }

    // ---------- commands ----------
    public static String generateCommand(String ctxHex, String sessionId, String key) throws Exception {
        String json = "{\"method\":\"POST\",\"body\":{\"plugin\":\"RemoteControl\",\"param1\":\"uuid:12345\",\"param2\":\"Click\",\"param3\":\""
                + key + "\",\"param4\":false,\"api\":\"SendRemoteKey\",\"version\":\"1.000\"}}";
        byte[] enc = aesEcb(unhex(ctxHex), json.getBytes(StandardCharsets.UTF_8), true, true);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < enc.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(enc[i] & 0xff);
        }
        return "5::/com.samsung.companion:{\"name\":\"callCommon\",\"args\":[{\"Session_Id\":" + sessionId
                + ",\"body\":\"[" + sb + "]\"}]}";
    }
}
