package com.smarttv.remote;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private EditText ipEdit, pinEdit;
    private TextView status, logView;
    private final StringBuilder logText = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tv", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#121212"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, dp(36), pad, pad);
        scroll.addView(root);

        TextView title = text("Samsung TV Remote (test)", 20, Color.WHITE);
        root.addView(title);

        ipEdit = new EditText(this);
        ipEdit.setHint("TV IP");
        ipEdit.setText(prefs.getString("ip", "192.168.1.2"));
        ipEdit.setTextColor(Color.WHITE);
        ipEdit.setHintTextColor(Color.GRAY);
        ipEdit.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(ipEdit);

        status = text("", 14, Color.parseColor("#80E0A0"));
        root.addView(status);

        LinearLayout pairRow = row();
        pairRow.addView(btn("Pair (show PIN)", new View.OnClickListener() {
            public void onClick(View v) { startPairing(); }
        }));
        pairRow.addView(btn("Forget pairing", new View.OnClickListener() {
            public void onClick(View v) {
                prefs.edit().remove("ctx").remove("sid").apply();
                refreshStatus();
            }
        }));
        root.addView(pairRow);

        LinearLayout pinRow = row();
        pinEdit = new EditText(this);
        pinEdit.setHint("PIN from TV");
        pinEdit.setTextColor(Color.WHITE);
        pinEdit.setHintTextColor(Color.GRAY);
        pinEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        pinEdit.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        pinRow.addView(pinEdit);
        pinRow.addView(btn("Confirm PIN", new View.OnClickListener() {
            public void onClick(View v) { confirmPin(); }
        }));
        root.addView(pinRow);

        root.addView(keyRow(new String[][]{{"Power", "KEY_POWEROFF"}, {"Source", "KEY_SOURCE"}, {"Mute", "KEY_MUTE"}}));
        root.addView(keyRow(new String[][]{{"Vol +", "KEY_VOLUP"}, {"Menu", "KEY_MENU"}, {"Ch +", "KEY_CHUP"}}));
        root.addView(keyRow(new String[][]{{"Vol -", "KEY_VOLDOWN"}, {"Smart Hub", "KEY_CONTENTS"}, {"Ch -", "KEY_CHDOWN"}}));
        root.addView(keyRow(new String[][]{{"", ""}, {"▲", "KEY_UP"}, {"", ""}}));
        root.addView(keyRow(new String[][]{{"◀", "KEY_LEFT"}, {"OK", "KEY_ENTER"}, {"▶", "KEY_RIGHT"}}));
        root.addView(keyRow(new String[][]{{"", ""}, {"▼", "KEY_DOWN"}, {"", ""}}));
        root.addView(keyRow(new String[][]{{"Back", "KEY_RETURN"}, {"Exit", "KEY_EXIT"}, {"Info", "KEY_INFO"}}));
        root.addView(keyRow(new String[][]{{"1", "KEY_1"}, {"2", "KEY_2"}, {"3", "KEY_3"}}));
        root.addView(keyRow(new String[][]{{"4", "KEY_4"}, {"5", "KEY_5"}, {"6", "KEY_6"}}));
        root.addView(keyRow(new String[][]{{"7", "KEY_7"}, {"8", "KEY_8"}, {"9", "KEY_9"}}));
        root.addView(keyRow(new String[][]{{"", ""}, {"0", "KEY_0"}, {"", ""}}));

        logView = text("", 11, Color.LTGRAY);
        root.addView(logView);

        setContentView(scroll);
        refreshStatus();
    }

    // ---------- UI helpers ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private Button btn(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 1f));
        return b;
    }

    private LinearLayout keyRow(String[][] keys) {
        LinearLayout r = row();
        for (final String[] k : keys) {
            if (k[1].isEmpty()) {
                View spacer = new View(this);
                spacer.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 1f));
                r.addView(spacer);
            } else {
                r.addView(btn(k[0], new View.OnClickListener() {
                    public void onClick(View v) { sendKey(k[1]); }
                }));
            }
        }
        return r;
    }

    private void refreshStatus() {
        boolean paired = prefs.getString("ctx", null) != null;
        status.setText(paired ? "Paired (saved key). Buttons work without a code." : "Not paired yet.");
    }

    private void setStatus(final String s) {
        runOnUiThread(new Runnable() { public void run() { status.setText(s); } });
    }

    private void addLog(final String s) {
        runOnUiThread(new Runnable() {
            public void run() {
                logText.append(s).append('\n');
                logView.setText(logText.toString());
            }
        });
    }

    private TvApi api() {
        String ip = ipEdit.getText().toString().trim();
        prefs.edit().putString("ip", ip).apply();
        return new TvApi(ip, new TvApi.Logger() { public void log(String s) { addLog(s); } });
    }

    // ---------- actions ----------
    private void startPairing() {
        final TvApi api = api();
        setStatus("Asking TV to show PIN...");
        exec.execute(new Runnable() {
            public void run() {
                try {
                    api.startPairing();
                    setStatus("Type the PIN shown on the TV, then tap Confirm PIN.");
                } catch (Exception e) {
                    setStatus("Error: " + e);
                    addLog("startPairing failed: " + e);
                }
            }
        });
    }

    private void confirmPin() {
        final String pin = pinEdit.getText().toString().trim();
        if (pin.isEmpty()) { status.setText("Enter the PIN first."); return; }
        final TvApi api = api();
        setStatus("Pairing...");
        exec.execute(new Runnable() {
            public void run() {
                try {
                    TvApi.Pairing p = api.pairWithPin(pin);
                    if (p == null) {
                        setStatus("PIN rejected or bad reply. Check PIN, tap Pair again.");
                    } else {
                        prefs.edit().putString("ctx", p.ctxHex).putString("sid", p.sessionId).apply();
                        runOnUiThread(new Runnable() { public void run() { refreshStatus(); } });
                    }
                } catch (Exception e) {
                    setStatus("Error: " + e);
                    addLog("pair failed: " + e);
                }
            }
        });
    }

    private void sendKey(final String key) {
        final String ctx = prefs.getString("ctx", null);
        final String sid = prefs.getString("sid", null);
        if (ctx == null) { status.setText("Pair first."); return; }
        final TvApi api = api();
        exec.execute(new Runnable() {
            public void run() {
                try {
                    api.sendKey(ctx, sid, key);
                    setStatus("Sent " + key);
                } catch (Exception e) {
                    setStatus("Error: " + e);
                    addLog("sendKey failed: " + e);
                }
            }
        });
    }
}
