package com.smarttv.remote;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Networking for Samsung H-series (2014) encrypted remote protocol. */
public class TvApi {
    public interface Logger { void log(String s); }

    static final String USER_ID = "654321";
    static final String APP_ID = "12345";
    static final String DEVICE_ID = "7e509404-9d7c-46b4-8f6a-e2a9668ad184";

    public static class Pairing {
        public String ctxHex;
        public String sessionId;
    }

    private final String ip;
    private final Logger logger;
    private final int pairPort = 8080;
    private final int cmdPort = 8000;

    public TvApi(String ip, Logger logger) {
        this.ip = ip;
        this.logger = logger;
    }

    private void log(String s) { if (logger != null) logger.log(s); }

    // ---------------- minimal HTTP client ----------------
    private String http(String method, int port, String path, String body) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, port), 5000);
            s.setSoTimeout(8000);
            byte[] b = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
            StringBuilder req = new StringBuilder();
            req.append(method).append(' ').append(path).append(" HTTP/1.1\r\n");
            req.append("Host: ").append(ip).append(':').append(port).append("\r\n");
            req.append("Accept: */*\r\n");
            req.append("Connection: close\r\n");
            if (body != null) req.append("Content-Length: ").append(b.length).append("\r\n");
            req.append("\r\n");
            OutputStream out = s.getOutputStream();
            out.write(req.toString().getBytes(StandardCharsets.UTF_8));
            if (b.length > 0) out.write(b);
            out.flush();

            InputStream in = s.getInputStream();
            String head = readHeaders(in);
            int contentLength = -1;
            boolean chunked = false;
            for (String line : head.split("\r\n")) {
                String l = line.toLowerCase();
                if (l.startsWith("content-length:")) {
                    try { contentLength = Integer.parseInt(l.substring(15).trim()); } catch (Exception ignored) { }
                } else if (l.startsWith("transfer-encoding:") && l.contains("chunked")) {
                    chunked = true;
                }
            }
            byte[] bodyBytes;
            if (chunked) bodyBytes = readChunked(in);
            else if (contentLength >= 0) bodyBytes = readExactly(in, contentLength);
            else bodyBytes = readToEnd(in);
            return new String(bodyBytes, StandardCharsets.UTF_8);
        } finally {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private static String readHeaders(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int state = 0;
        while (true) {
            int c = in.read();
            if (c < 0) break;
            o.write(c);
            if ((state == 0 || state == 2) && c == '\r') state++;
            else if ((state == 1 || state == 3) && c == '\n') state++;
            else state = (c == '\r') ? 1 : 0;
            if (state == 4) break;
        }
        return o.toString("UTF-8");
    }

    private static byte[] readExactly(InputStream in, int n) throws IOException {
        byte[] buf = new byte[n];
        int off = 0;
        try {
            while (off < n) {
                int r = in.read(buf, off, n - off);
                if (r < 0) break;
                off += r;
            }
        } catch (SocketTimeoutException ignored) { }
        return java.util.Arrays.copyOf(buf, off);
    }

    private static byte[] readToEnd(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        try {
            int r;
            while ((r = in.read(buf)) >= 0) o.write(buf, 0, r);
        } catch (SocketTimeoutException ignored) { }
        return o.toByteArray();
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') o.write(c);
        }
        return o.toString("UTF-8");
    }

    private static byte[] readChunked(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try {
            while (true) {
                String line = readLine(in).trim();
                if (line.isEmpty()) continue;
                int semi = line.indexOf(';');
                if (semi >= 0) line = line.substring(0, semi);
                int size = Integer.parseInt(line, 16);
                if (size == 0) break;
                o.write(readExactly(in, size));
                readLine(in);
            }
        } catch (SocketTimeoutException ignored) { }
        return o.toByteArray();
    }

    // ---------------- pairing ----------------
    private String pairUrl(int step) {
        return "/ws/pairing?step=" + step + "&app_id=" + APP_ID + "&device_id=" + DEVICE_ID;
    }

    /** Shows the PIN on the TV screen (if it is not already shown). */
    public void startPairing() throws IOException {
        String page = http("GET", pairPort, "/ws/apps/CloudPINPage", null);
        Matcher m = Pattern.compile("state>([^<>]*)</state>", Pattern.CASE_INSENSITIVE).matcher(page);
        String state = m.find() ? m.group(1) : "";
        log("PIN page state: " + state);
        if (state.equals("stopped")) {
            http("POST", pairPort, "/ws/apps/CloudPINPage", "pin4");
            log("PIN page opened on TV");
        } else {
            log("PIN already on TV");
        }
    }

    /** Returns Pairing on success, null if PIN wrong. Throws on network / protocol errors. */
    public Pairing pairWithPin(String pin) throws Exception {
        http("GET", pairPort, pairUrl(0) + "&type=1", null);

        Spc.Hello hello = Spc.generateServerHello(USER_ID, pin);
        String content = "{\"auth_Data\":{\"auth_type\":\"SPC\",\"GeneratorServerHello\":\""
                + Spc.hex(hello.serverHello).toUpperCase() + "\"}}";
        String r1 = http("POST", pairPort, pairUrl(1), content);
        log("step1 reply: " + shorten(r1));

        Matcher mReq = Pattern.compile("request_id[^0-9]*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(r1);
        Matcher mHello = Pattern.compile("GeneratorClientHello[^:]*:[^0-9a-zA-Z]*([0-9a-zA-Z]+)", Pattern.CASE_INSENSITIVE).matcher(r1);
        if (!mReq.find() || !mHello.find()) return null;
        int requestId = Integer.parseInt(mReq.group(1));
        String clientHello = mHello.group(1);

        Spc.Parsed parsed = Spc.parseClientHello(clientHello, hello.hash, hello.aesKey, USER_ID);
        if (parsed == null) return null;
        log("PIN accepted");

        String ack = Spc.generateServerAcknowledge(parsed.skPrime);
        String content2 = "{\"auth_Data\":{\"auth_type\":\"SPC\",\"request_id\":\"" + requestId
                + "\",\"ServerAckMsg\":\"" + ack + "\"}}";
        String r2 = http("POST", pairPort, pairUrl(2), content2);
        log("step2 reply: " + shorten(r2));
        if (r2.contains("secure-mode")) throw new Exception("TV asked for secure-mode (not supported by this test app)");

        Matcher mAck = Pattern.compile("ClientAckMsg[^:]*:[^0-9a-zA-Z]*([0-9a-zA-Z]+)", Pattern.CASE_INSENSITIVE).matcher(r2);
        Matcher mSess = Pattern.compile("session_id[^0-9]*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(r2);
        if (!mAck.find() || !mSess.find()) throw new Exception("Could not read session_id / ClientAckMsg from TV");
        if (!Spc.parseClientAcknowledge(mAck.group(1), parsed.skPrime)) throw new Exception("TV acknowledge did not match");

        try { http("DELETE", pairPort, "/ws/apps/CloudPINPage/run", null); } catch (Exception ignored) { }

        Pairing p = new Pairing();
        p.ctxHex = Spc.hex(parsed.ctx);
        p.sessionId = mSess.group(1);
        log("Paired. session_id=" + p.sessionId);
        return p;
    }

    private static String shorten(String s) {
        s = s.replace("\n", " ");
        return s.length() > 160 ? s.substring(0, 160) + "..." : s;
    }

    // ---------------- sending keys ----------------
    public void sendKey(String ctxHex, String sessionId, String key) throws Exception {
        String r = http("GET", cmdPort, "/socket.io/1/?t=" + System.currentTimeMillis(), null);
        String id = r.trim().split(":")[0];
        if (id.isEmpty()) throw new Exception("No socket.io handshake id from TV");
        String path = "/socket.io/1/websocket/" + id;

        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, cmdPort), 5000);
            s.setSoTimeout(5000);
            byte[] rnd = new byte[16];
            new SecureRandom().nextBytes(rnd);
            String wsKey = android.util.Base64.encodeToString(rnd, android.util.Base64.NO_WRAP);
            String req = "GET " + path + " HTTP/1.1\r\n"
                    + "Host: " + ip + ":" + cmdPort + "\r\n"
                    + "Upgrade: websocket\r\n"
                    + "Connection: Upgrade\r\n"
                    + "Sec-WebSocket-Key: " + wsKey + "\r\n"
                    + "Sec-WebSocket-Version: 13\r\n"
                    + "Origin: http://" + ip + ":" + cmdPort + "\r\n\r\n";
            OutputStream out = s.getOutputStream();
            out.write(req.getBytes(StandardCharsets.UTF_8));
            out.flush();
            String head = readHeaders(s.getInputStream());
            if (!head.startsWith("HTTP/1.1 101") && !head.contains(" 101 ")) {
                throw new Exception("WebSocket refused: " + head.split("\r\n")[0]);
            }
            Thread.sleep(350);
            wsSend(out, "1::/com.samsung.companion");
            Thread.sleep(350);
            wsSend(out, Spc.generateCommand(ctxHex, sessionId, key));
            Thread.sleep(350);
            try { out.write(new byte[]{(byte) 0x88, (byte) 0x80, 0, 0, 0, 0}); out.flush(); } catch (Exception ignored) { }
        } finally {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private static void wsSend(OutputStream out, String text) throws IOException {
        byte[] payload = text.getBytes(StandardCharsets.UTF_8);
        byte[] mask = new byte[4];
        new SecureRandom().nextBytes(mask);
        ByteArrayOutputStream f = new ByteArrayOutputStream();
        f.write(0x81);
        if (payload.length < 126) {
            f.write(0x80 | payload.length);
        } else if (payload.length < 65536) {
            f.write(0x80 | 126);
            f.write((payload.length >> 8) & 0xff);
            f.write(payload.length & 0xff);
        } else {
            f.write(0x80 | 127);
            for (int i = 7; i >= 0; i--) f.write((int) (((long) payload.length >> (8 * i)) & 0xff));
        }
        f.write(mask, 0, 4);
        for (int i = 0; i < payload.length; i++) f.write(payload[i] ^ mask[i % 4]);
        out.write(f.toByteArray());
        out.flush();
    }
}
